var ellipseRadius = 500;

function setup() {
   createCanvas(800, 600);
}

function draw() {
    ellipse(width / 2, height / 2, ellipseRadius, ellipseRadius);
}