function setup() {
    createCanvas(400, 400);
}

function draw() {
    ellipse(50,50,100,100);
}